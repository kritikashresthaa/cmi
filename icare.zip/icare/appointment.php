<?php
/*
Template Name: Career Template
*/
?>
<style>
	textarea{ height:50px !important; }
</style>
<?php get_header(); ?>
    <div class="clearfix"></div>  
    <div class="map-Section">
            <div>
            </div>
        <!-- </div> -->
    </div>

    <div class="container">
        <div class="contact-Section" style="margin-top:40px;">
<?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?>

            <div class="contact-Body" style="margin-top:0px;">
                <div class="row">
					<div class="col-md-8">
                        <div class="sign-Section">
							<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
							<?php the_content(); ?>
							<?php endwhile; endif; ?>
                        </div>
                    </div> 
                    <div class="col-md-4 contacts">
                         <?php dynamic_sidebar('career');?>   
                    </div>
                            
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
<?php get_footer(); ?>