<?php get_header(); ?>
<div id="brief_intro">
		<div class="row">
			<div class="container">
				<div class="col-md-8 mobile_center">
					<h1 class="mobile_center">News & Updates.</h1>
				</div>
				<div class="col-md-4 hidden-xs">
					<a href="<?php echo get_permalink(18);?>" class="btn btn-default btn-lg">Learn More</a>
				</div>
			</div>
		</div>
</div>
<!--/Ends brief intro -->
<div class="container">
<div class="page_content">			
					<div class="col-md-9 news_image" role="main">
						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
							<header>
								<?php the_title("<h1>","</h1>") ?>							
								<p class="meta"><?php _e("Posted", "wpbootstrap"); ?> <time datetime="<?php echo the_time('Y-m-j'); ?>" pubdate><?php the_time(); ?></time> .</p>
							</header> <!-- end article header -->
							<?php the_post_thumbnail('gal-thumb');?>
							<?php the_content(); ?>
							<span class='st_facebook_hcount' st_title='<?php the_title(); ?>' st_url='<?php the_permalink(); ?>'></span>
<span class='st_linkedin_hcount' st_title='<?php the_title(); ?>' st_url='<?php the_permalink(); ?>'></span>
<span class='st_plusone_hcount' st_title='<?php the_title(); ?>' st_url='<?php the_permalink(); ?>'></span>

					</div>
					<div class="col-md-3">
					<?php get_sidebar(); ?>
					</div>
					<?php endwhile; ?>			
					<?php else : ?>
					<article id="post-not-found">
					    <header>
					    	<h1><?php _e("Not Found", "wpbootstrap"); ?></h1>
					    </header>
					    <section class="post_content">
					    	<p><?php _e("Sorry, but the requested resource was not found on this site.", "wpbootstrap"); ?></p>
					    </section>
					</article>
					<?php endif; ?>
</div>
<div class="col-md-3">
<?php get_sidebar();?>
</div>
</div>
<?php get_footer(); ?>