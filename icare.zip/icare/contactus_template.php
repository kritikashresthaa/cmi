<?php
/*
Template Name: ContactUs Template
*/
?>
<style>
	textarea{ height:50px !important; }
</style>
<?php get_header(); ?>
    <div class="clearfix"></div>  
    <div class="map-Section">
            <div>
                <div>
                    <iframe
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3533.958516778294!2d85.32899701459958!3d27.656755134321443!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39eb17a6d46ec4ab%3A0xb41c622a7c9af56f!2sDekha%20Herbals%20Pvt.%20Ltd!5e0!3m2!1sen!2snp!4v1569480775538!5m2!1sen!2snp"
                        width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
                </div>
            </div>
        <!-- </div> -->
    </div>

    <div class="container">
        <div class="contact-Section" style="margin-top:40px;">
<?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?>

            <div class="contact-Body" style="margin-top:0px;">
                <div class="row">
                    <div class="col-md-8 contacts">
                         <?php dynamic_sidebar('contactform');?>   
                    </div>
                    <div class="col-md-4">
                        <div class="sign-Section">
							<?php dynamic_sidebar('contact');?>
                        </div>
                    </div>              
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
<?php get_footer(); ?>