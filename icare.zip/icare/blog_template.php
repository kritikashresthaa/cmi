<?php
/*
Template Name: Blog Template
*/
?>
<?php get_header(); ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div id="brief_intro">
		<div class="row">
			<div class="container">
				<div class="col-md-8 mobile_center">
					<h1 class="mobile_center"><?php the_title();?></h1>
				</div>
				<div class="col-md-4 hidden-xs">
					<a href="#" class="btn btn-default btn-lg">Learn More</a>
				</div>
			</div>
		</div>
</div>
<!--/Ends brief intro -->
<?php
endwhile; 
endif; ?>
<div class="container">
	
		<div class="page_content ">
		<div class="col-md-12">
			<?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?>
		<div class="row">	
		<?php
				if ( get_query_var('paged') ) {
				   $paged = get_query_var('paged');
				} else if ( get_query_var('page') ) {
				   $paged = get_query_var('page');
				} else {
				   $paged = 1;
				}	
							$args = array( 'post_type' => 'post', 'posts_per_page' => 6, 'paged' => $paged );
							$loop = new WP_Query( $args );
							while( $loop->have_posts() ) : $loop->the_post(); ?>
							<div class="col-md-6 newspost">

							
							<a href="<?php the_permalink();?>"><?php the_post_thumbnail('wpbs-featured',array("class"=>"img-fluid feature_image")); ?></a>
							<a href="<?php the_permalink();?>"> <?php the_title("<h3 style='margin-top:20px;'>","</h3>"); ?></a>
								<?php the_excerpt(); ?>
							
							</div>
							<?php 
							$j=$j+1;
							endwhile; ?>
		</div>
		</div>
</div>
</div>
<?php
if ( function_exists('vb_pagination') ) {
  vb_pagination($loop);
}
?>	




<?php 

get_footer();?>