<?php get_header(); ?>
<!--/Ends brief intro -->
<div class="container-fluid nopadding">		
					<div class="col-md-12 nopadding" role="main">
						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                        <div class="container-fluid nopadding blur_bg">           
                            <div class="container">
                                <div class="col-md-2"></div>
                                <div class="col-md-4" >
                                    <?php the_post_thumbnail('gal-thumb',array('style'=>'padding-top:20px;'));?>
                                </div>
                                <div class="col-md-6">
                                    <div style="padding-top: 60px;
    background: #EEE;
    padding-left: 25px;
    padding-bottom: 25px;">
                                        <?php the_title("<h1 style='font-size: 22px;margin: 0px;'>","</h1>") ?>	
                                        <h2 style="margin: 5px 0px;text-transform: uppercase;"><?php echo get_post_meta($post->ID,'designation',true);?></h2>
                                        <h3 style="background: #2D98E0;
    padding: 10px;
    width: auto;
    display: inline-block;
    color: #FFF;"><?php echo get_post_meta($post->ID,'reg_no',true);?></h3>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="container" style="padding:30px 0px;">
							<?php the_content(); ?>
                        </div>

					<?php endwhile; ?>			
					<?php else : ?>
					<article id="post-not-found">
					    <header>
					    	<h1><?php _e("Not Found", "wpbootstrap"); ?></h1>
					    </header>
					    <section class="post_content">
					    	<p><?php _e("Sorry, but the requested resource was not found on this site.", "wpbootstrap"); ?></p>
					    </section>
					</article>
					<?php endif; ?>
</div>
    </div>
</div>
<?php get_footer(); ?>