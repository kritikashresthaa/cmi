<?php 
/*
Template Name: Homepage
*/
?>
<?php get_header();?>
<style>
.circle {
  width: 300px;
  height: 300px;
  border-radius: 150px;
  border: 1px solid #000;
  position: relative;
  margin: 50px auto;
}

.text {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

</style>
<div class="container2">
  <div class="text">Hello World!</div>
</div>
<?php echo do_shortcode('[wonderplugin_slider id=1]'); ?>
    <div class="clearfix"></div>
    <div class="row">
		<div class="col-md-2"></div>
			<div class="col-md-8">
				<div class="h-100 p-1 text-center">
				  <h2>caremarts</h2>
				  <h1>WHO WE ARE</h2>
				  <br/>
				  <p>Established in 2010, Ganapati Jewellers Nepal Pvt. Ltd. has become the benchmark for quality and designs of jewellery in Nepal.
				  We guarantee all our products to be of the top most purity and the finest craftsmanship. Visit our store to explore our exquisite Diamond, Gold and Silver collections.</p><br/>
				  <!--button class="btn btn-outline-secondary btn-shop mb-4" type="button">EXPLORE</button-->
				</div>
			</div>
		<div class="col-md-2"></div>
  </div>
<!-----ENDS --------->
<section class="standard-pad-50" style="padding-bottom:70px;">
<h2 class="strok-text text-center">NUTRITIONS</h2>
<h4 class="text-center">Facts</h4>
<div class="row">
	<div class="col-md-1"></div>
	<div class="col-md-3">
		<div class="p-4">
			<div class="vlist">
				<h3>VITAMIN A and B</h3>
				<p>We guarantee all our products to be of the top most purity and the finest craftsmanship.</p>
			</div>
			<div class="vlist">
				<h3>ANTI-OXIDANTS</h3>
				<p>We guarantee all our products to be of the top most purity and the finest craftsmanship.</p>
			</div>
		</div>
	</div>
	<div class="col-md-4">
		<div class="box-bind">
			<img src="http://localhost/icaremarts/wp-content/uploads/2023/02/nutrition-products.jpg" class="img-fluid ott"  />
		</div>
	</div> 
	<div class="col-md-3">
		<div class="p-4">
			<div class="vlist">
				<h3>VITAMIN A and B</h3>
				<p>We guarantee all our products to be of the top most purity and the finest craftsmanship.</p>
			</div>
			<div class="vlist">
				<h3>VITAMIN E</h3>
				<p>We guarantee all our products to be of the top most purity and the finest craftsmanship.</p>
			</div>
		</div>
	</div>
	<div class="col-md-1"></div>
</div>
</section>
<!-----ENDS --------->
<section class="standard-pad parallex">
	<div class="container">
		<h1 class="text-center fade-in-text">PRODUCTS</h1>
		<p class="text-center">Healthy Supplements</p>
		<br/>
		<div class="row">
			 <?php
					$c=1;
					 $pargs = array(
								'post_type'      => 'product',
								'post_status'    => 'publish',
						 		'posts_per_page' => 4,
						 		'order'			=> 'DESC',
							);
					$loop = new WP_Query( $pargs );
					while ( $loop->have_posts() ) : $loop->the_post(); 
						global $product; 
						?>
								<div class="col-md-3 col-6 img-center">
										<div class="thumbnail">
											<?php woocommerce_show_product_sale_flash( $post, $product ); ?>
											<?php the_post_thumbnail('medium',array('class'=>'img-fluid'));?>
											<div class="caption1 text-center pt-3">
												<a href="<?php the_permalink();?>"><?php the_title("<h5>","</h5>"); ?></a><span class="price" ><?php echo $product->get_price_html(); ?></span> 
												<?php woocommerce_template_loop_add_to_cart( $loop->post, $product ); ?>
											</div>
										</div>
								</div>			
						<?php 
						$c++;
					endwhile;
					?>	
		<!-- end shop -->
		</div>
	</div>
</section>
<!-----ENDS --------->
<section class="standard-pad">
    <div class="row">
		<div class="col-md-3"></div>
			<div class="col-md-6">
				<div class="h-100 p-1 text-center">
				  <h2>caremarts</h2>
				  <h1>CAREER OPPURNITY</h1>
				  
				  <p class="pt-4">Established in 2010, Ganapati Jewellers Nepal Pvt. Ltd. has become the benchmark for quality and designs of jewellery in Nepal.
				  We guarantee all our products to be of the top most purity and the finest craftsmanship. Visit our store to explore our exquisite Diamond, Gold and Silver collections.</p><br/>
				  <!--button class="btn btn-outline-secondary btn-shop mb-4" type="button">EXPLORE</button-->
				</div>
			</div>
		<div class="col-md-3"></div>
	</div>
	<div class="container ds">		
		<div class="mb-5" style="width:300px; height:300px;background:orange;text-align:center; border-radius:50%; margin:0px auto;">
			<img src="http://localhost/icaremarts/wp-content/uploads/2023/02/ds-icon.png" class="img-fluid p-5" alt="direct selling in nepal" />
		</div>
			<div class="row">
				<div class="col-md-6">
					<div class="ds-card p-5">
						<h3>About Direct Selling</h3>
						<p>Ganapati Jewellers Nepal Pvt. Ltd. has become the benchmark for quality and designs.
					  We guarantee all our products to be of the top most purity and the finest craftsmanship.</p>
					  <small><a href="#" class="btn btn-default btn-outline-warning btn-xs">Learn More</a></small>
					</div>
				</div>
				<div class="col-md-6">
					<div class="ds-card p-5">
						<h3>About Direct Selling</h3>
						<p>Ganapati Jewellers Nepal Pvt. Ltd. has become the benchmark for quality and designs.
					  We guarantee all our products to be of the top most purity and the finest craftsmanship.</p>
					   <small><a href="#" class="btn btn-default btn-outline-warning btn-xs">Learn More</a></small>
					</div>
				</div>
				<div class="col-md-6">
					<div class="ds-card p-5">
						<h3>About Direct Selling</h3>
						<p>Ganapati Jewellers Nepal Pvt. Ltd. has become the benchmark for quality and designs.
					  We guarantee all our products to be of the top most purity and the finest craftsmanship.</p>
					   <small><a href="#" class="btn btn-default btn-outline-warning btn-xs">Learn More</a></small>
					</div>
				</div>
				<div class="col-md-6">
					<div class="ds-card p-5">
						<h3>About Direct Selling</h3>
						<p>Ganapati Jewellers Nepal Pvt. Ltd. has become the benchmark for quality and designs.
					  We guarantee all our products to be of the top most purity and the finest craftsmanship.</p>
					   <small><a href="#" class="btn btn-default btn-outline-warning btn-xs">Learn More</a></small>
					</div>
				</div>
			</div>
			<a href="#" class="btn btn-default btn-warning btn-lg mt-4 mb-4">JOIN US NOW</a>
	</div>
</section>
<!-----ENDS --------->
<section class="standard-pad">
	<div class="h-100 pt-5 mb-5 text-center">
		<h2>caremarts</h2>
		<h1>MEDIA UPDATES</h2>
		<p>Subscribe to our Newsletter to get latest updates.</p>
	</div>	
	<div class="container">
	<div class="row">
		<div class="col-md-5">
		<img src="http://localhost/icaremarts/wp-content/uploads/2021/07/1-copy_result.jpg" class="img-fluid" />
		</div>
		<div class="col-md-6" style="border:1px #cccccc solid;">
			<div class="mt-5 p-5">
			<h3>Media Title Runs here</h3>
			<p>Ganapati Jewellers Nepal Pvt. Ltd. has become the benchmark for quality and designs.
			We guarantee all our products to be of the top most purity and the finest craftsmanship.</p>
			<a href="#" class="btn btn-success btn-default">Read More</a>
			</div>
		</div>
	</div>
	</div>
</section>
<section class="standard-pad-50">
	<div class="h-100 p-1 text-center">
		<h2>caremarts</h2>
		<h1>SUCCESS STORIES</h2>
	</div>	
	<div class="container">
	<div class="row">
		<div class="col-md-4"></div>
		<div class="col-md-4">
		<img src="http://localhost/icaremarts/wp-content/uploads/2023/02/success-story.jpg" class="img-fluid" />
		</div>
		<div class="col-md-4"></div>
	</div>
	<div class="row" style="margin-top:-65px;">
		<div class="col-md-4">
			<div class="story p-5">
				<img src="http://localhost/icaremarts/wp-content/uploads/2023/02/default-user.png"  style="width:70px;" />
				<h4>Aashik Mnanahdar</h4>
				<p>Ganapati Jewellers Nepal Pvt. Ltd. has become the benchmark for quality and designs.
				We guarantee all our products to be of the top most purity and the finest craftsmanship.</p>
				<a href="#" class="btn btn-default btn-outline-success">Success Story</a>
			</div>
		</div>
		<div class="col-md-4">
			<div class="story p-5">
				<img src="http://localhost/icaremarts/wp-content/uploads/2023/02/default-user.png"  style="width:70px;" />
				<h4>Aashik Mnanahdar</h4>
				<p>Ganapati Jewellers Nepal Pvt. Ltd. has become the benchmark for quality and designs.
				We guarantee all our products to be of the top most purity and the finest craftsmanship.</p>
				<a href="#" class="btn btn-default btn-outline-success">Success Story</a>
			</div>
		</div>
		<div class="col-md-4">
			<div class="story p-5">
				<img src="http://localhost/icaremarts/wp-content/uploads/2023/02/default-user.png"  style="width:70px;" />
				<h4>Aashik Mnanahdar</h4>
				<p>Ganapati Jewellers Nepal Pvt. Ltd. has become the benchmark for quality and designs.
				We guarantee all our products to be of the top most purity and the finest craftsmanship.</p>
				<a href="#" class="btn btn-default btn-outline-success">Success Story</a>
			</div>
		</div>
	</div>
	
	
	</div>
</section>
<!-----ENDS --------->
<section class="standard" style="height:150px;margin-top:-140px; padding-top:180px; background:#eb984b;"></section>
<?php get_footer();?>