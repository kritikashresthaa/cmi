<?php
/*
Template Name: AboutUs Template
*/
?>
<?php get_header();?>
<?php $aboutus = get_post('49');?>
    <div class="container">
        <div class="page_content aboutUs-Section">
				<?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?>
             <p class="who-Detail21"><?php echo $aboutus->post_content;?></p>

            <div class="row" style="margin-top: 10px;">
                <div class="col-md-12">
                    <div class="row aboutBody-Div">
                        <div class="col-md-6 nopadding">
                            <div class="media about-Body">
								 <i style="font-size:30px; color:#00a2e3;"
                                    class="fa fa-check-circle align-self-center mr-3 "></i>
                                <div class="media-body">
									<h5 class="mt-0 about-Head">VISION</h5>
                                    <p class="mb-0 about-Detail">To serve people with natural products </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 nopadding">
                            <div class="media about-Body">
								 <i style="font-size:30px; color:#00a2e3;"
                                    class="fa fa-check-circle align-self-center mr-3 "></i>
                                <div class="media-body ">
                                  <h5 class="mt-0 about-Head">MISSION</h5>
                                    <p class="mb-0 about-Detail">To create and promote healthy and natural products</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 nopadding">
                            <div class="media about-Body">
                                <i style="font-size:30px; color:#00a2e3;"
                                    class="fa fa-check-circle align-self-center mr-3 "></i>

                                <div class="media-body">
                                    <h5 class="mt-0 about-Head">Values</h5>
									<p class="mb-0 about-Detail">We believe in nature and it’s creation which helps to heal our body and soul.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 nopadding">
                            <div class="media about-Body">
                                <i style="font-size:30px; color:#00a2e3;"
                                    class="fa fa-check-circle align-self-center mr-3 "></i>
                                <div class="media-body">
                                    <h5 class="mt-0 about-Head">Goal</h5>

                                    <p class="mb-0 about-Detail">To produce quality ayurvedic medicine and products that we eat & use in our daily life</p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>

    <div class="container">
        <div class="director-Section">
            <div style="text-align: center;">
                <h1 class="head1">DEKHA HERBALS</h1>
                <?php $director_message = (get_post('116'));?>
               
            </div>
            <div class="row abt-Details">
                <div class="col-md-1 col-2"></div>
                <div class="col-md-3 col-8 director-Image" style="text-align: center;">
                <?php $director_image=wp_get_attachment_image_src( get_post_thumbnail_id( 116) ,'large')?>
                    <img src="<?php echo $director_image[0];?>" class="img-fluid director-Img"> 
                    <img src="http://saayamitech.com.np/dekha-wp/wp-content/uploads/2020/07/dekha-logo.jpg" class="img-fluid dir-Logo">
                </div>
                <div class="col-md-7" style="padding: 0px 40px;">
					 <h3 class="head_chairman_msg"><?php echo $director_message->post_title;?></h3>
                    <?php echo  $director_message->post_content;?>
                    
                </div>
                <div class="col-md-1 col-2"></div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>

    <div class="container">
        <div class="quote-Section">
            <blockquote class="quote-card green-card">
                <p>
                    Nature's Gift for Good Health
                </p>

                <cite>
                    Dekha Group of Companies
                </cite>
            </blockquote>
        </div>
    </div>
    <div class="clearfix"></div>
    <div>
        <div class="group-Image">
            <!--img src="http://localhost/dekha-wp/wp-content/uploads/2019/09/group.jpeg" class="img-fluid grp-Img"-->
        </div>
    </div>
<?php get_footer();?>