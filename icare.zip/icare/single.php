<?php get_header(); ?>
<div id="brief_intro">
		<div class="row">
			<div class="container">
				<div class="col-md-9 mobile_center">
					<h1 class="mobile_center">Blog Post</h1>
				</div>
			</div>
		</div>
</div>
<!--/Ends brief intro -->
<div class="container">
<div class="page_content row">			
					<div class="col-md-9 news_image" role="main">
						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
							<header>
								<?php the_title("<h1>","</h1>") ?>							
								<p class="meta"><?php _e("Posted", "wpbootstrap"); ?> <time datetime="<?php echo the_time('Y-m-j'); ?>" pubdate><?php the_date(); ?></time> .</p>
							</header> <!-- end article header -->
							<?php the_post_thumbnail('gal-thumb',array('class'=>'img-responsive','style'=>'margin-bottom:20px'));?>
							<?php the_content(); ?>
                        <?php
		// Author bio.
		if ( is_single() && get_the_author_meta( 'description' ) ) :
			get_template_part( 'author-bio' );
		endif;
	?>
							<div class="gap clearfix"></div>
                        <?php
// If comments are open or we have at least one comment, load up the comment template.
			/*if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif; */
                        ?>
							
					</div>
					<div class="col-md-3">
					<?php get_sidebar(); ?>
					</div>
					<?php endwhile; ?>			
					<?php else : ?>
					<article id="post-not-found">
					    <header>
					    	<h1><?php _e("Not Found", "wpbootstrap"); ?></h1>
					    </header>
					    <section class="post_content">
					    	<p><?php _e("Sorry, but the requested resource was not found on this site.", "wpbootstrap"); ?></p>
					    </section>
					</article>
					<?php endif; ?>
</div>
</div>
<?php get_footer(); ?>