<section class="standard-pad footerbg">
<div class="container">
		<div class="row">
			<div class="col-md-4 col-12">
		
			</div>
			<div class="col-md-4 col-12">
				<div class="ganapati-logo1 text-center">
					<img src="http://localhost/icaremarts/wp-content/uploads/2023/02/jumpman.png" class="img-fluid" />
				</div>
				<div class="text-center">
					<h3>Care Marts International P.Ltd.</h3>
					<p>Chabahil, kathmandu</p>
					<p>
					Tel: 01-2398742983 <br/>
					Email : info@icaremarts.com</p>
				</div>
			</div>
			<div class="col-12 col-md-4">

			</div>
		</div>
	</div>
    <div class="clearfix"></div>
    <div id="footer-Section">
        <div class="footer-Detail">
            <div class="container">
			<div class="hide-mobile">
                <a href="#" class="footer-Link">Privacy and Policy</a>
                <a href="#" class="footer-Link">Terms & Condition</a>
                <a href="#" class="footer-Link">FAQs</a>
                <a href="#" class="footer-Link">Shipping</a>
				<a href="#" class="footer-Link">Disclaimer Policy</a>
			</div>
                <hr style="background-color: yellowgreen; margin: 15px 0px;">
				<small>These statements have not been evaluated by the Food and Drug Administration. The information on this website is for educational and selling purposes only and is not a substitute for medical advice, diagnosis or self treatment. For more information pertaining to your personal needs please see a qualified health practitioner.</small>
				  <hr style="background-color: yellowgreen; margin: 15px 0px;">
                <p class="foot-Detail" style="font-size:14px;">
                    &copy; 2022-2023 Care Marts International, All Rights Reserved.
                   <br>
                    Website by: <a href="http://www.saayami.com" class="foot-Link" target="_blank">SAAYAMI</a>
                </p>

            </div>

        </div>

    </div>
	</section>
    <?php wp_footer(); ?>
</body>
<script src="<?php echo get_template_directory_uri();?>/library/js/bootstrap.js"></script>
<script src="<?php echo get_template_directory_uri();?>/library/js/owl.carousel.min.js"></script>
<script>
function openSearch() {
  document.getElementById("myOverlay").style.display = "block";
}

function closeSearch() {
  document.getElementById("myOverlay").style.display = "none";
}
</script>
<script type="text/javascript">
jQuery(window).scroll(function(){
			jQuery('.fixed-top').toggleClass('scrolled', jQuery(this).scrollTop() > 500);
	});
	jQuery(document).ready(function(){
    jQuery(".woocommerce-product-search>button").html('<i class="fa fa-search"></i>');
	jQuery(".select2-selection__placeholder").text("Product Filter");
    jQuery(document).on('click','.btn_bc',function(e) {
                var id=jQuery(this).attr('id');
				jQuery('#ajax_dashboard').html("<img src='<?php echo get_template_directory_uri();?>/images/ajax.gif' class='ajax-loader' style='padding:18% 45%;' />");
				var ds="cat_id="+id;
					jQuery.ajax({
					  type: "POST",
					  url: "<?php echo get_template_directory_uri();?>/subpage-ajax.php",
					  data: ds,
					  success: function(data)
					  {
						jQuery('#ajax_dashboard').html(data).hide().fadeIn("slow");
						//var c = jQuery('#team_profile').offset().top;
						//jQuery('html, body').animate({scrollTop: jQuery("#team_profile").offset().top-40}, 800);
					  }
					});
					return false;
            });
});
	jQuery('.owl-carousel1').owlCarousel({
    loop:true,
    margin:10,
    responsiveClass:true,
    responsive:{
        0:{
            items:1,
            nav:true
        },
        600:{
            items:3,
            nav:false
        },
        1000:{
            items:5,
            nav:true,
            loop:false
        }
    }
})
    jQuery('.owl-carousel').owlCarousel({
        loop: true,
        margin: 10,
        responsiveClass: true,
        responsive:{
			0:{
            items:2,
            nav:true
        },
        600:{
            items:3,
            nav:false
        },
        1000:{
            items:6,
            nav:true,
            loop:false
        }
		}
    });
    jQuery('.carousel').carousel({interval: 5000 })
</script>

</html>