<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php wp_title( '|', true, 'right' ); ?></title>
	<!-- Bootstrap core CSS -->
	<link href="css/" rel="stylesheet">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Raleway:wght@400&display=swap" rel="stylesheet">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri();?>/library/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri();?>/library/css/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri();?>/library/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
    <?php wp_head(); ?>
</head>
<body id="fullmenubar">
<div class="fixed-top">
        <div class="container" >
            <div class="row ">
                <div class="col-md-2 col-7 dekha-Logo">
                    <a href="<?php echo home_url('/');?>"><img src="http://localhost/icaremarts/wp-content/uploads/2023/02/icare_logo.png" class="img-fluid" ></a>
                </div>
                <div class="col-md-8 col-1 top-Link top-Search" style="text-align: center;">
						<?php wp_nav_menu( array( 'theme_location' => 'main_nav' ) ); ?>
                </div>
                <div class="col-md-2 col-5 top-Link2 text-center">	
					<!--h5 class="cs"><button class="openBtn" onclick="openSearch()"><i class="fa fa-search"></i></button><i class="fa fa-phone"></i>&nbsp; +9771-5523488</h5-->
                    <?php dynamic_sidebar('woomenu');?>
                </div>
            </div>
		</div>
</div>
<div class="clearfix"></div>
<div id="myOverlay" class="overlay">
	<span class="closebtn" onclick="closeSearch()" title="Close Overlay">×</span>
	<div class="overlay-content">
		<?php dynamic_sidebar('product_search');?>
	</div>
</div>
<?php if(is_product()){ ?>
<style>
	.sidebar-shop{ display:none; }
</style>
<?php } ?>