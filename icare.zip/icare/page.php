<?php get_header(); ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID),'full'); ?>
<?php if(isset($image[0])):?>
	<section class="module parallax_1 parallax_3" style="background:url(<?php echo $image[0]; ?>);background-size:cover;">
        <div class="container">
		<?php the_title("<h3 class='p-page-title'>","</h3>"); ?>
        </div>
    </section>
<?php else:?>
<div id="brief_intro">
		<div class="row">
			<div class="container">
				<div class="col-md-12 mobile_center">
					<h1 class="wow fadeInUp animated"><?php the_title();?></h1>
				</div>
			</div>
		</div>
</div>
<!--/Ends brief intro -->
<?php endif; ?>
<div class="container">
		<div class="page_content">
		<div class="col-md-12">
		<?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?>  
		<?php the_content(); ?>
		</div>
		</div>
</div>
<?php endwhile; ?>		
					<?php else : ?>
					<div class="container">
					<div class="page_content">
					<div class="col-md-12">
					    <header><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
					    	<h1><?php _e("Not Found", "wpbootstrap"); ?></h1>
					    </header>
					    <section class="post_content">
					    	<p><?php _e("Sorry, but the requested resource was not found on this site.", "wpbootstrap"); ?></p>
					    </section>
					</div>
					</div>
					</div>
					<?php endif; ?>
<?php get_footer(); ?>