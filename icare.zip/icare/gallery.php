<?php
/*
Template Name: Photo Gallery Templates
*/
?>
<?php get_header(); ?>
<div class="clearfix"></div>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID),'full'); ?>
<div id="brief_intro">
		<div class="row">
			<div class="container">
				<div class="col-md-8 mobile_center">
					<h1 class="wow fadeInUp animated mobile_center">Photo Gallery </h1>
				</div>
			</div>
		</div>
</div>
<!--/Ends brief intro -->
<?php 
endwhile;
endif; ?>
<div class="container">		
			<div id="content" class="clearfix row" style="padding-bottom:50px;">			
				<div id="main" class="col-sm-12 clearfix" role="main">
				<?php
                $fabricTerms = get_terms( 'portfolio_cats'); 
                foreach($fabricTerms as $fabricTerm){
                ?>
                        <?php
                        global $wpdb;
                        // create blank array..
                        $fabricPosts = array();
                        // find term_id for sub-category..
                        $fabric_category_term_id = $wpdb->get_results( "SELECT term_id FROM {$wpdb->terms} WHERE name = '".$fabricTerm->name."'  " );
                        foreach($fabric_category_term_id as $fc_id){
                            // find taxonomy_ids from term_id..
                            $fabric_taxonomy_id = $wpdb->get_results( "SELECT term_taxonomy_id FROM {$wpdb->term_taxonomy} WHERE term_id = ".$fc_id->term_id." " );
                            foreach($fabric_taxonomy_id as $ft_id){
                                // find object_id from taxonomy_id..
                                $fabric_object_id = $wpdb->get_results( "SELECT object_id FROM {$wpdb->term_relationships} WHERE term_taxonomy_id = ".$ft_id->term_taxonomy_id." " );
                                foreach($fabric_object_id as $fo_id){
                                    // add object_id to array..
                                    array_push($fabricPosts, $fo_id->object_id);
                                }
                            }
                        }
                        // if less than 5 posts, get number of posts to detirmine number of loops..
                        if( count($fabricPosts) < 1 ){
                            $loops = count($fabricPosts);
                        }
                        else {
                            $loops = 1;
                        }
                        // loop through posts..
                        for($v=0; $v<$loops; $v++){
                            // get the 1st element from the array..
                            $fabricPost = array_shift($fabricPosts);
                            // get post data..
                            $post = get_post($fabricPost);	
            ?>
             <div class="col-md-4 col-sm-4 col-xs-12 " style="margin-top:50px;">
			 <div class="item item-type-line">

			 <a class="item-hover" href="<?php echo add_query_arg( array('var1' => $fabricTerm->name ), home_url().'?page_id=1149'); ?>" target="_blank">
					<div class="item-info">
						<div class="headline"><span class="glyphicon glyphicon-picture" aria-hidden="true"></span> <?php echo $fabricTerm->name;?></div>
					</div>
			</a>
        <a href="<?php echo add_query_arg( array('var1' => $fabricTerm->name ), home_url().'?page_id=1149'); ?>" title="View <?php $name = get_post_meta($post->ID, 'Fabric Name', true); echo $name; ?> - <?php the_title_attribute(); ?>"><?php the_post_thumbnail('gal-vthumb',array("class"=>"fmc_gallery img-responsive")); ?>
</a></div>
</div>                                                                                                 
<?php  
    }   
}						
     ?>             
<?php
if ( function_exists('vb_pagination') ) {
  vb_pagination($loop);
}
?>	
</div>
</div> <!-- end #main -->
</div> <!-- end #content -->
<?php get_footer();?>