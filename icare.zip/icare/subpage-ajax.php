<?php
    $path = $_SERVER['DOCUMENT_ROOT'];
    define('WP_USE_THEMES', false);
    require($path .'/dekha-wp/wp-load.php');
	require_once(dirname(__FILE__).'/../../../wp-config.php');
	require_once(dirname(__FILE__).'/../../../wp-admin/upgrade-functions.php');	
	global $wpdb, $post;
	$profiles='';
	if(isset($_POST['cat_id'])):
					$c=1;
					 $pargs = array(
								'post_type'             => 'product',
								'post_status'           => 'publish',
								'ignore_sticky_posts'   => 1,
								'posts_per_page'        => '12',
								'tax_query'             => array(
									array(
										'taxonomy'      => 'product_cat',
										'field' => 'term_id', //This is optional, as it defaults to 'term_id'
										'terms'         => $_POST['cat_id'],
										'operator'      => 'IN' // Possible values are 'IN', 'NOT IN', 'AND'.
									)
								)
							);
					$loop = new WP_Query( $pargs );?>
					<div class="row first-row">
					<?php 
					while ( $loop->have_posts() ) : $loop->the_post(); 
						global $product; 
						if($c==5 || $c==9 || $c==13)
							echo "<div class='clearfix'></div>";
						?>
								<div class="col-md-3 col-sm-4 col-6">
										<div class="medicine">
											<?php woocommerce_show_product_sale_flash( $post, $product ); ?>
											<a href="<?php the_permalink();?>" class="pro_home">
											<?php the_post_thumbnail('medium',array('class'=>'img-fluid'));?>
											</a>
													<?php the_title("<p class='med-Head'>","</p>"); ?>	
													<span class="price" ><?php echo $product->get_price_html(); ?></span> 
													<?php woocommerce_template_loop_add_to_cart( $loop->post, $product ); ?>
										</div>
								</div>			
						<?php 
						$c++;
					endwhile;?>
					</div>
					<?php 

			else:
			echo "Products Not Found!"; 
			endif;
	
?>