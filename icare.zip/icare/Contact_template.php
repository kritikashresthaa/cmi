<?php
/*
Template Name: Contact Template
*/
?>
<?php get_header(); ?>
<style>
.wpcf7-form{
padding:30px 10px !important;
}
.black{
color:#444;
}
	.wpcf7-submit,div.wpcf7-validation-errors, div.wpcf7-mail-sent-ok{
		color:#000;
	}
</style>
	<?php dynamic_sidebar('google_map');?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="container">
		<div class="page_content">
		<div class="col-md-12">
	
			<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer1') ) : ?>
		            <?php endif; ?>
		            <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer2') ) : ?>
		            <?php endif; ?>
		            <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer3') ) : ?>
		            <?php endif; ?>
					 <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer4') ) : ?>
		            <?php endif; ?>
					<div class="gap"></div>
					<?php the_content();?>
				<div class="clearfix"></div>
				<!-- Map start here -->
		</div>
		</div>
</div>
<?php endwhile; ?>		
					<?php else : ?>
					<div class="container">
					<div class="page_content">
					<div class="col-md-12">
					    <header>
					    	<h1><?php _e("Not Found", "wpbootstrap"); ?></h1>
					    </header>
					    <section class="post_content">
					    	<p><?php _e("Sorry, but the requested resource was not found on this site.", "wpbootstrap"); ?></p>
					    </section>
					</div>
					</div>
					</div>
					<?php endif; ?>
<?php get_footer(); ?>
