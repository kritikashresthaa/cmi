<?php
/*
Template Name: AyurvedicQuiz
*/
?>
<style>
label{
text-transform:capitalize;
	}
	b{color:#00a4e5;}
</style>
<?php get_header(); ?>
			<div id="content" class="clearfix">
				<div id="main" class="clearfix" role="main">
				<div class="container-fluid" style="background:#fbfbfb;padding:60px 0px;">
                    <div class="container">
					<?php if (have_posts()) : while (have_posts()) : the_post(); 
						the_content(); 
					endwhile; 
					endif; 
					?>
					</div>
				</div>
					<div class="result" >
                    
                     </div>
						<div class="container">
                            <div class="row" style="font-weight:bold;padding:15px 0px;">
                                <div class="col-md-3">Aspects</div>
                                <div class="col-md-3">VATA Air/Space</div>
                                <div class="col-md-3">PITTA Fire </div>
                                <div class="col-md-3">KAPHA Earth/Water</div>
                            </div>
                            <div class="row">
                                <div class="col-md-3"><b>Body types</b></div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input vata" type="checkbox" name="vata"  value="tst"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Extreme: Tall, Short, Thin
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input pitta" type="checkbox" name="pitta"  value="mm"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Medium, Muscular
                                        </label>
                                    </div> 
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input kapha" type="checkbox" name="kapha"  value="ss"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Solid, Sturdy
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3"><b>Hands</b></div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input vata" type="checkbox" name="vata"  value="dcp"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Dry, Cold, Pallid
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input pitta" type="checkbox" name="pitta"  value="mrw"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Medium, Red, Warm
                                        </label>
                                    </div> 
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input kapha" type="checkbox" name="kapha"  value="wsc"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Wide, Strong, Cool
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3"><b>Hair</b></div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input vata" type="checkbox" name="vata"  value="h1"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Coarse, Dry, Wild, Unruly
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input pitta" type="checkbox" name="pitta"  value="fot"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Fine, Oily, Thinning
                                        </label>
                                    </div> 
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input kapha" type="checkbox" name="kapha"  value="tl"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Thick, Lustrous
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3"><b>Teeth</b></div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input vata" type="checkbox" name="vata"  value="lcr"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Large, Crooked, Receeding gums
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input pitta" type="checkbox" name="pitta"  value="mg"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Medium size soft/pick gums
                                        </label>
                                    </div> 
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input kapha" type="checkbox" name="kapha"  value="sw"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Strong, White
                                        </label>
                                    </div>
                                </div>
                            </div>
							<p style="margin:0px;"><b>Tongue</b></p>
                            <div class="row">
                                <div class="col-md-3 xx">General</div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input vata" type="checkbox" name="vata"  value="tst"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Thin, Small, Trembling
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input pitta" type="checkbox" name="pitta"  value="mp"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Medium-sized, Pointed
                                        </label>
                                    </div> 
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input kapha" type="checkbox" name="kapha"  value="lrt"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Large, round , thick
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3 xx">Color</div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input vata" type="checkbox" name="vata"  value="pd"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Pale, Dull
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input pitta" type="checkbox" name="pitta"  value="ryg"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Red, Yellow, green
                                        </label>
                                    </div> 
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input kapha" type="checkbox" name="kapha"  value="pw"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Pale, White
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3 xx">Coating</div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input vata" type="checkbox" name="vata"  value="bb"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Brown or black
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input pitta" type="checkbox" name="pitta"  value="y"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Yellow
                                        </label>
                                    </div> 
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input kapha" type="checkbox" name="kapha"  value="wm"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                           White, Mucous
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3 xx">Moisture</div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input vata" type="checkbox" name="vata"  value="d"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Dry
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input pitta" type="checkbox" name="pitta"  value="mrd"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Moist or red & dry
                                        </label>
                                    </div> 
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input kapha" type="checkbox" name="kapha"  value="w"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Wet
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3"><b>Eye</b></div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input vata" type="checkbox" name="vata"  value="sdd"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Small, Dry, Dull
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input pitta" type="checkbox" name="pitta"  value="ms"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Medium, Sharp
                                        </label>
                                    </div> 
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input kapha" type="checkbox" name="kapha"  value="lat"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Large, Attractive, Thick
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
								<div class="col-md-3"><b>Appetite</b></div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input vata" type="checkbox" name="vata"  value="v"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Variable
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input pitta" type="checkbox" name="pitta"  value="se"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Strong, excessive
                                        </label>
                                    </div> 
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input kapha" type="checkbox" name="kapha"  value="sc"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                           Slow but constant
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
								<div class="col-md-3"><b>Thrist</b></div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input vata" type="checkbox" name="vata"  value="tv"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Variable
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input pitta" type="checkbox" name="pitta"  value="es"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Excessive, strong
                                        </label>
                                    </div> 
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input kapha" type="checkbox" name="kapha"  value="sl"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Scanty, Little
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
								<div class="col-md-3"><b>Elimination</b></div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input vata" type="checkbox" name="vata"  value="dhc"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Dry, hard, constipated 
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input pitta" type="checkbox" name="pitta"  value="sol"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Soft, oily, loose 
                                        </label>
                                    </div> 
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input kapha" type="checkbox" name="kapha"  value="tihs"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            thick, oily, heavy, slow
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
								<div class="col-md-3"><b>Activity</b></div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input vata" type="checkbox" name="vata"  value="fit"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Fit of excitement, Followed by fatigue
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input pitta" type="checkbox" name="pitta"  value="ap"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Assertive and to the point
                                        </label>
                                    </div> 
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input kapha" type="checkbox" name="kapha"  value="pr"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Prefer to relax
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3"><b>Temperature</b></div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input vata" type="checkbox" name="vata"  value="cei"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Changable, erratic , insecure
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input pitta" type="checkbox" name="pitta"  value="eiagj"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            easily irritated, aggressive, jealous
                                        </label>
                                    </div> 
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input kapha" type="checkbox" name="kapha"  value="cda"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Calm, difficult to ruffle attached
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3"><b>Mind</b></div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input vata" type="checkbox" name="vata"  value="do"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Drifts off
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input pitta" type="checkbox" name="pitta"  value="qc"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            quick, certain
                                        </label>
                                    </div> 
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input kapha" type="checkbox" name="kapha"  value="sg"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                           Slow, but good memory
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
								<div class="col-md-3"><b>Memory</b></div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input vata" type="checkbox" name="vata"  value="gp"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Good-short term, Poor-long term
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input pitta" type="checkbox" name="pitta"  value="s"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Sharp
                                        </label>
                                    </div> 
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input kapha" type="checkbox" name="kapha"  value="sp"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Slow but prolonged
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
								<div class="col-md-3"><b>Sleep</b></div>
                                
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input vata" type="checkbox" name="vata"  value="si"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Scanty, insomnia 
                                        </label>
                                    </div> 
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input pitta" type="checkbox" name="pitta"  value="ls"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Little but sound 
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input kapha" type="checkbox" name="kapha"  value="hp"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Heavy, prolonged 
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
								<div class="col-md-3"><b>Speech</b></div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input vata" type="checkbox" name="vata"  value="si"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Scanty, insomnia 
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input pitta" type="checkbox" name="pitta"  value="sh"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            sharp, cutting, load   
                                        </label>
                                    </div> 
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input kapha" type="checkbox" name="kapha"  value="sm"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            slow, monotonous
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
								<div class="col-md-3"><b>Financially</b></div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input vata" type="checkbox" name="vata"  value="easy"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Earns, spend money easily
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input pitta" type="checkbox" name="pitta"  value="ml"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Moderate, likes luxuries
                                        </label>
                                    </div> 
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input kapha" type="checkbox" name="kapha"  value="save"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            save money
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
								<div class="col-md-3"><b>Pulse</b></div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input vata" type="checkbox" name="vata"  value="snake"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Erratic, Thread, Snake-like
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input pitta" type="checkbox" name="pitta"  value="frog"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Moderate, Frog-like
                                        </label>
                                    </div> 
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input kapha" type="checkbox" name="kapha"  value="swan"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Broad, Slow, Swan-like
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
								<div class="col-md-3"><b>Urination</b></div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input vata" type="checkbox" name="vata"  value="et"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Erratic, thready, Snake-like
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input pitta" type="checkbox" name="pitta"  value="ps"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Profuse, strong color/odour
                                        </label>
                                    </div> 
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input kapha" type="checkbox" name="kapha"  value="pps"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Profuse, Pale, Swan-like
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
								<div class="col-md-3"><b>Nails</b></div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input vata" type="checkbox" name="vata"  value="dbt"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Dry, brittle, thin
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input pitta" type="checkbox" name="pitta"  value="sp"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Soft, pink
                                        </label>
                                    </div> 
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input kapha" type="checkbox" name="kapha"  value="smp"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Smooth, pink, oily, strong
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
								<div class="col-md-3"><b>Circulation</b></div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input vata" type="checkbox" name="vata"  value="pce"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Poor, cold extremities
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input pitta" type="checkbox" name="pitta"  value="gw"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Good, Warm
                                        </label>
                                    </div> 
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input class="form-check-input kapha" type="checkbox" name="kapha"  value="sbs"  >
                                        <label class="form-check-label" for="exampleRadios1">
                                            Slow but stready
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3"></div>
                                <div class="col-md-3">
                                   <input type="text" class="tvata" value="0" disabled> Total Vata
                                   
                                </div>
                                <div class="col-md-3">
                                    <input type="text" class="tpitta" value="0" disabled> Total Pitta
                                    
                                </div>
                                <div class="col-md-3">
                                   <input type="text" class="tkapha" value="0" disabled> Total Kapha
                                    
                                </div>
                            </div>
                            <div class="row">
                                <button type="button" class="btn btn-success get_result">Submit</button>
                            </div>
                            
                        </div>
					
				</div> <!-- end #main -->
    
			</div> <!-- end #content -->

<?php get_footer(); ?>
<script>
    jQuery(document).on('click','.vata',function(){
        var id=0;
        jQuery('input[name="vata"]:checked').each(function() {
            id++;
        });
        jQuery(".tvata").val(id);    
    })
    jQuery(document).on('click','.pitta',function(){
        var id="";
        jQuery('input[name="pitta"]:checked').each(function() {
            id++;
        });
        jQuery(".tpitta").val(id);    
    })
    jQuery(document).on('click','.kapha',function(){
        var id="";
        jQuery('input[name="kapha"]:checked').each(function() {
            id++;
        });
        jQuery(".tkapha").val(id);
    })
    
    jQuery(document).on("click",'.get_result',function()
    {
		var mynam=jQuery('#myname').val();
		var myemail=jQuery('#myemail').val();
		if(mynam!="" || myemail!="")
			{
				var list={ Vata:jQuery(".tvata").val() ,Pitta: jQuery(".tpitta").val(), Kapha:jQuery(".tkapha").val()};
       
				sortedval = Object.keys(list).sort(
					function(a,b)
					{
					   return list[b]-list[a]
					}
					)
				jQuery('.result').html('Result based on your selection: '+sortedval);
				jQuery('.wpcf7-textarea').html('Result:'+sortedval);
			}
				jQuery('.wpcf7-submit ').trigger('click');
				jQuery('html, body').animate({scrollTop:0}, 'fast');
       
    });

</script>