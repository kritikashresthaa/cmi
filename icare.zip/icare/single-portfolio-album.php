<?php
/**
 * Template Name: single Album template
 */
?>
<?php get_header(); ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div id="brief_intro">
		<div class="row">
			<div class="container">
				<div class="col-md-8 mobile_center">
					<h1 class="wow fadeInUp animated mobile_center">Gallery / <?php echo $_GET['var1'];?></h1>
				</div>
			</div>
		</div>
</div>
<!--/Ends brief intro -->
<?php 
endwhile;
endif; ?>
<div class="container">		
			<div id="content" class="clearfix row" >			
			<div id="main" class="col-sm-12 clearfix" style="margin:50px 0px;" role="main">
	<?php
            query_posts(array(
				'term' => $_GET['var1'],
                'post_type'=>'portfolio',
                'posts_per_page' => -1,
				'taxonomy'=>'portfolio_cats'		
            ));
            ?>       
            <?php
			$count=0;
            while (have_posts()) : the_post();
			$count++;
            $thumbail = wp_get_attachment_image_src(get_post_thumbnail_id(), 'thumb');			
            //get terms
            $terms = get_the_terms( get_the_ID(), 'portfolio_cats' );  
			if ( has_post_thumbnail() ) {  ?>

                 <div class="col-sm-3 col-xs-12 " style="overflow:hidden;">
					<div class="item item-type-line">
				<a href="<?php echo $thumbail[0]; ?>" rel="lightbox" ><?php the_post_thumbnail('gal-vthumb',array("class"=>"img-responsive"));?> </a>
				</div>
</div>
            <?php 
			}
			endwhile; ?>
<?php wp_reset_query(); ?>
</div></div></div>
<?php get_footer(); ?>