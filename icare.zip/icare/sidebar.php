<?php
dynamic_sidebar( 'sidebar-1' );
dynamic_sidebar('recent_post');
dynamic_sidebar('aboutus');
?>

				