<?php
    $path = $_SERVER['DOCUMENT_ROOT'];
    define('WP_USE_THEMES', false);
    require($path .'/wireframes/wp-load.php');
	require_once(dirname(__FILE__).'/../../../wp-config.php');
	require_once(dirname(__FILE__).'/../../../wp-admin/upgrade-functions.php');	
	global $wpdb, $post;
	 if(isset($_POST['tid']))
	 {
		$args = array( 
			'type'                     => 'post', 
			'child_of'                 => ''.$_POST['tid'].'', 
			'orderby'                  => 'name', 
			'order'                    => 'ASC', 
			'hide_empty'               => 1, 
			'hierarchical'             => 1, 
			'exclude'                  => '', 
			'include'                  => '', 
			'number'                   => '', 
			'taxonomy'                 => 'portfolio_cats', 
			'pad_counts'               => false ); 
			print_r($args);
			$categories = get_categories($args); 
			
			echo '<ul>'; 
			foreach ($categories as $category) { 
				$url = get_term_link($category);
				$url.="&tid=".$category->term_id;
				?>
    <li style="padding:10px; border-bottom:1px #CCC solid;"><a href="#" class="abc" value="<?php echo $category->term_id;?> "><?php echo $category->name; ?></a>
    <span style="margin-left:30px;">Total:<?php echo $category->category_count;?></span></li> 
<?php 
} 

echo '</ul>'; 
		 
		 
	 }
	 else
	 {
		 
		 echo "error";
		 
	 }
?>