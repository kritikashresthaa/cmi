<?php
/*
Author: Eddie Machado
URL: htp://themble.com/bones/

This is where you can drop your custom functions or
just edit things like thumbnail sizes, header images, 
sidebars, comments, ect.
*/

// Get Bones Core Up & Running!
require_once('library/bones.php');            // core functions (don't remove)

// Shortcodes
require_once('library/shortcodes.php');

// Admin Functions (commented out by default)
// require_once('library/admin.php');         // custom admin functions

// Custom Backend Footer
add_filter('admin_footer_text', 'wp_bootstrap_custom_admin_footer');
function wp_bootstrap_custom_admin_footer() {
	echo '<span id="footer-thankyou">Developed by <a href="http://saayami.com" target="_blank">Saayami</a></span>';
}
 add_theme_support('woocommerce');
// adding it to the admin area
add_filter('admin_footer_text', 'wp_bootstrap_custom_admin_footer');

// Set content width
if ( ! isset( $content_width ) ) $content_width = 580;

/************* THUMBNAIL SIZE OPTIONS *************/

// Thumbnail sizes
add_image_size( 'gal-vthumb', 350, 250, true );
add_image_size( 'gal-thumb_large', 500, 400, true );
add_image_size( 'wpbs-featured', 650, 400, true );

/* 
to add more sizes, simply copy a line from above 
and change the dimensions & name. As long as you
upload a "featured image" as large as the biggest
set width or height, all the other sizes will be
auto-cropped.

To call a different size, simply change the text
inside the thumbnail function.

For example, to call the 300 x 300 sized image, 
we would use the function:
<?php the_post_thumbnail( 'bones-thumb-300' ); ?>
for the 600 x 100 image:
<?php the_post_thumbnail( 'bones-thumb-600' ); ?>

You can change the names and dimensions to whatever
you like. Enjoy!
*/

/************* ACTIVE SIDEBARS ********************/

// Sidebars & Widgetizes Areas
function wp_bootstrap_register_sidebars() {
    register_sidebar(array(
    	'id' => 'sidebar1',
    	'name' => 'Main Sidebar',
    	'description' => 'Used on every page BUT the homepage page template.',
    	'before_widget' => '<div id="%1$s" class="widget %2$s">',
    	'after_widget' => '</div>',
    	'before_title' => '<h4 class="widgettitle">',
    	'after_title' => '</h4>',
    ));
	 register_sidebar(array(
    	'id' => 'woomenu',
    	'name' => 'Cart Section',
    	'description' => 'Used on every page BUT the homepage page template.',
    	'before_widget' => '<div id="%1$s" class="widget %2$s">',
    	'after_widget' => '</div>',
    	'before_title' => '<h4 class="widgettitle">',
    	'after_title' => '</h4>',
    ));
	register_sidebar(array(
      'id' => 'footer_image',
      'name' => 'Footer Image',
      'before_widget' => '<div id="%1$s" class="widget %2$s">',
      'after_widget' => '</div>',
    ));
	register_sidebar(array(
      'id' => 'contact',
      'name' => 'Contact',
      'before_widget' => '',
      'after_widget' => '',
      'before_title' => '<h4 class="quick_contact">',
      'after_title' => '</h4>',
    ));
     register_sidebar(array(
      'id' => 'sidebar-shop',
      'name' => 'Shop Sidebar',
      'before_widget' => '',
      'after_widget' => '',
      'before_title' => '<h4 class="quick_contact">',
      'after_title' => '</h4>',
    ));
    register_sidebar(array(
      'id' => 'product_search',
      'name' => 'Product Search',
      'before_widget' => '',
      'after_widget' => '',
      'before_title' => '<h4 class="quick_contact">',
      'after_title' => '</h4>',
    ));
	register_sidebar(array(
      'id' => 'phone',
      'name' => 'Phone number',
      'before_widget' => '',
      'after_widget' => '',
      'before_title' => '<h4 class="quick_contact">',
      'after_title' => '</h4>',
    ));
	register_sidebar(array(
      'id' => 'contactform',
      'name' => 'Contact Form',
      'before_widget' => '',
      'after_widget' => '',
      'before_title' => '<h4 class="quick_contact">',
      'after_title' => '</h4>',
    ));
	register_sidebar(array(
      'id' => 'promobox',
      'name' => 'Promo Box',
      'before_widget' => '',
      'after_widget' => '',
      'before_title' => '<h4 class="quick_contact">',
      'after_title' => '</h4>',
    ));

   register_sidebar(array(
      'id' => 'recent_post',
      'name' => 'Recent Post',
      'before_widget' => '<div id="%1$s" class="widget %2$s">',
      'after_widget' => '</div>',
      'before_title' => '<h4 class="quick_contact_sidebar"><span>',
      'after_title' => '</span></h4>',
    ));
	 register_sidebar(array(
      'id' => 'career',
      'name' => 'Career',
      'before_widget' => '<div id="%1$s" class="widget %2$s">',
      'after_widget' => '</div>',
      'before_title' => '<h4 class="quick_contact_sidebar"><span>',
      'after_title' => '</span></h4>',
    ));
    
    remove_filter('widget_text_content', 'wpautop');
    /* 
    to add more sidebars or widgetized areas, just copy
    and edit the above sidebar code. In order to call 
    your new sidebar just use the following code:
    
    Just change the name to whatever your new
    sidebar's id is, for example:
    
    To call the sidebar in your template, you can just copy
    the sidebar.php file and rename it to your sidebar's name.
    So using the above example, it would be:
    sidebar-sidebar2.php
    
    */
} // don't remove this bracket!
	
// Enable shortcodes in widgets
add_filter( 'widget_text', 'do_shortcode' );

// Disable jump in 'read more' link
function remove_more_jump_link( $link ) {
	$offset = strpos($link, '#more-');
	if ( $offset ) {
		$end = strpos( $link, '"',$offset );
	}
	if ( $end ) {
		$link = substr_replace( $link, '', $offset, $end-$offset );
	}
	return $link;
}
add_filter( 'the_content_more_link', 'remove_more_jump_link' );
// Remove height/width attributes on images so they can be responsive
add_filter( 'post_thumbnail_html', 'remove_thumbnail_dimensions', 10 );
add_filter( 'image_send_to_editor', 'remove_thumbnail_dimensions', 10 );

function remove_thumbnail_dimensions( $html ) {
    $html = preg_replace( '/(width|height)=\"\d*\"\s/', "", $html );
    return $html;
}
// Add the Meta Box to the homepage template
function add_homepage_meta_box() {  
	global $post;
	// Only add homepage meta box if template being used is the homepage template
	// $post_id = isset($_GET['post']) ? $_GET['post'] : (isset($_POST['post_ID']) ? $_POST['post_ID'] : "");
	$post_id = $post->ID;
	$template_file = get_post_meta($post_id,'_wp_page_template',TRUE);
	if ( $template_file == 'page-homepage.php' ){
	    add_meta_box(  
	        'homepage_meta_box', // $id  
	        'Optional Homepage Tagline', // $title  
	        'show_homepage_meta_box', // $callback  
	        'page', // $page  
	        'normal', // $context  
	        'high'); // $priority  
    }
}
add_action( 'add_meta_boxes', 'add_homepage_meta_box' );
// Field Array  
$prefix = 'custom_';  
$custom_meta_fields = array(  
    array(  
        'label'=> 'Homepage tagline area',  
        'desc'  => 'Displayed underneath page title. Only used on homepage template. HTML can be used.',  
        'id'    => $prefix.'tagline',  
        'type'  => 'textarea' 
    )  
);  
// The Homepage Meta Box Callback  
function show_homepage_meta_box() {  
  global $custom_meta_fields, $post;
  // Use nonce for verification
  wp_nonce_field( basename( __FILE__ ), 'wpbs_nonce' );
  // Begin the field table and loop
  echo '<table class="form-table">';
  foreach ( $custom_meta_fields as $field ) {
      // get value of this field if it exists for this post  
      $meta = get_post_meta($post->ID, $field['id'], true);  
      // begin a table row with  
      echo '<tr> 
              <th><label for="'.$field['id'].'">'.$field['label'].'</label></th> 
              <td>';  
              switch($field['type']) {  
                  // text  
                  case 'text':  
                      echo '<input type="text" name="'.$field['id'].'" id="'.$field['id'].'" value="'.$meta.'" size="60" /> 
                          <br /><span class="description">'.$field['desc'].'</span>';  
                  break;                 
                  // textarea  
                  case 'textarea':  
                      echo '<textarea name="'.$field['id'].'" id="'.$field['id'].'" cols="80" rows="4">'.$meta.'</textarea> 
                          <br /><span class="description">'.$field['desc'].'</span>';  
                  break;  
              } //end switch  
      echo '</td></tr>';  
  } // end foreach  
  echo '</table>'; // end table  
}  
// Save the Data  
function save_homepage_meta( $post_id ) {  
    global $custom_meta_fields;  
    // verify nonce  
    if ( !isset( $_POST['wpbs_nonce'] ) || !wp_verify_nonce($_POST['wpbs_nonce'], basename(__FILE__)) )  
        return $post_id;
    // check autosave
    if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE )
        return $post_id;
    // check permissions
    if ( 'page' == $_POST['post_type'] ) {
        if ( !current_user_can( 'edit_page', $post_id ) )
            return $post_id;
        } elseif ( !current_user_can( 'edit_post', $post_id ) ) {
            return $post_id;
    }
    // loop through fields and save the data  
    foreach ( $custom_meta_fields as $field ) {
        $old = get_post_meta( $post_id, $field['id'], true );
        $new = $_POST[$field['id']];

        if ($new && $new != $old) {
            update_post_meta( $post_id, $field['id'], $new );
        } elseif ( '' == $new && $old ) {
            delete_post_meta( $post_id, $field['id'], $old );
        }
    } // end foreach
}
add_action( 'save_post', 'save_homepage_meta' );

// Add thumbnail class to thumbnail links
function add_class_attachment_link( $html ) {
    $postid = get_the_ID();
    $html = str_replace( '<a','<a class="thumbnail"',$html );
    return $html;
}
add_filter( 'wp_get_attachment_link', 'add_class_attachment_link', 10, 1 );



// Menu output mods
class Bootstrap_walker extends Walker_Nav_Menu{

  function start_el(&$output, $object, $depth = 0, $args = Array(), $current_object_id = 0){

	 global $wp_query;
	 $indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';
	
	 $class_names = $value = '';
	
		// If the item has children, add the dropdown class for bootstrap
		if ( $args->has_children ) {
			$class_names = "dropdown ";
		}
	
		$classes = empty( $object->classes ) ? array() : (array) $object->classes;
		
		$class_names .= join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $object ) );
		$class_names = ' class="'. esc_attr( $class_names ) . ' nav-item" ';
       
   	$output .= $indent . '<li id="menu-item-'. $object->ID . '"' . $value . $class_names .'>';

   	$attributes  = ! empty( $object->attr_title ) ? ' title="'  . esc_attr( $object->attr_title ) .'"' : '';
   	$attributes .= ! empty( $object->target )     ? ' target="' . esc_attr( $object->target     ) .'"' : '';
   	$attributes .= ! empty( $object->xfn )        ? ' rel="'    . esc_attr( $object->xfn        ) .'"' : '';
   	$attributes .= ! empty( $object->url )        ? ' href="'   . esc_attr( $object->url        ) .'"' : '';

   	// if the item has children add these two attributes to the anchor tag
   	// if ( $args->has_children ) {
		  // $attributes .= ' class="dropdown-toggle" data-toggle="dropdown"';
    // }

    $item_output = $args->before;
	if ( $args->has_children ) {
    	$item_output .= '<a'. $attributes  .' class="dropdown-toggle nav-link nav-List" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true">';
    }
    else {
    	$item_output .= '<a'. $attributes  .' class="nav-link nav-List">';
    }

    //$item_output .= '<a'. $attributes  .' class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true">';
    $item_output .= $args->link_before .apply_filters( 'the_title', $object->title, $object->ID );
    $item_output .= $args->link_after;

    // if the item has children add the caret just before closing the anchor tag
    if ( $args->has_children ) {
    	$item_output .= '<b class="caret"></b></a>';
    }
    else {
    	$item_output .= '</a>';
    }

    $item_output .= $args->after;

    $output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $object, $depth, $args );
  } // end start_el function
        
  function start_lvl(&$output, $depth = 0, $args = Array()) {
	if($depth==0)
		$depthnumber='';
	else
		$depthnumber=$depth+1;
    $output .= "\n$indent<ul class=\"dropdown-menu".$depthnumber."\">\n";
    //$indent = str_repeat("\t", $depth);
   // $output .= "\n$indent<ul class=\"dropdown-menu\">\n";
  }
      
	function display_element( $element, &$children_elements, $max_depth, $depth=0, $args, &$output ){
    $id_field = $this->db_fields['id'];
    if ( is_object( $args[0] ) ) {
        $args[0]->has_children = ! empty( $children_elements[$element->$id_field] );
    }
    return parent::display_element( $element, $children_elements, $max_depth, $depth, $args, $output );
  }        
}
add_editor_style('editor-style.css');
// Add Twitter Bootstrap's standard 'active' class name to the active nav link item
add_filter('nav_menu_css_class', 'add_active_class', 10, 2 );
function add_active_class($classes, $item) {
	if( $item->menu_item_parent == 0 && in_array('current-menu-item', $classes) ) {
    $classes[] = "active";
	}
  return $classes;
}
// enqueue styles
if( !function_exists("theme_styles") ) {  
    function theme_styles() { 
        // This is the compiled css file from LESS - this means you compile the LESS file locally and put it in the appropriate directory if you want to make any changes to the master bootstrap.css.
        wp_register_style( 'bootstrap', get_template_directory_uri() . '/library/css/bootstrap.min.css', array(), '1.0', 'all' );
        wp_enqueue_style( 'bootstrap' );

        // For child themes
        wp_register_style( 'wpbs-style', get_stylesheet_directory_uri() . '/style.css', array(), '1.2', 'all' );
        wp_enqueue_style( 'wpbs-style' );
    }
}
add_action( 'wp_enqueue_scripts', 'theme_styles' );
// enqueue javascript
if( !function_exists( "theme_js" ) ) {  
  function theme_js(){
	  wp_register_script( 'jquery', 
      get_template_directory_uri() . '/library/js/jquery-1.7.1.min.js', 
      array('jquery'), 
      '1.7.1' ); 
    wp_register_script( 'bootstrap', 
      get_template_directory_uri() . '/library/js/bootstrap.min.js', 
      array('jquery'), 
      '1.2' ); 

    wp_register_script(  'modernizr', 
      get_template_directory_uri() . '/library/js/modernizr.full.min.js', 
      array('jquery'), 
      '1.2' );
    wp_enqueue_script('jquery');
	  wp_enqueue_script('bootstrap');
    wp_enqueue_script('modernizr'); 
  }
}
add_action( 'wp_enqueue_scripts', 'theme_js' );
// Theme built in Pagination
function vb_pagination( $query=null ) {
 
  global $wp_query;
  $query = $query ? $query : $wp_query;
  $big = 999999999;
 
  $paginate = paginate_links( array(
    'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
    'type' => 'array',
    'total' => $query->max_num_pages,
    'format' => '?paged=%#%',
    'current' => max( 1, get_query_var('paged') ),
    'prev_text' => __('&laquo;'),
    'next_text' => __('&raquo;'),
    )
  );
   if ($query->max_num_pages > 1) :
?>
<ul class="pagination">
  <?php
  foreach ( $paginate as $page ) {
    echo '<li>' . $page . '</li>';
  }
  ?>
</ul>
<?php
  endif;
}
/*-----------------------------------------------------------------------------------*/
/*	Custom Post 
/*-----------------------------------------------------------------------------------*/
add_action( 'init', 'adapt_create_post_presentation' );
function adapt_create_post_presentation() {
	register_post_type( 'presentation',
		array(
		  'labels' => array(
			'name' => __( 'Presentation', '' ),
			'singular_name' => __( 'Presentation', '' ),		
			'add_new' => _x( 'Add New', 'Presentation', '' ),
			'add_new_item' => __( 'Add Presentation', '' ),
			'edit_item' => __( 'Edit Presentation', '' ),
			'new_item' => __( 'New Presentation', '' ),
			'view_item' => __( 'View Presentation', '' ),
			'search_items' => __( 'Search Presentation', '' ),
			'not_found' =>  __( 'No Team Found', '' ),
			'not_found_in_trash' => __( 'No Team found in Trash', '' ),
			'parent_item_colon' => ''		
		  ),
		  'public' => true,
		    'menu_icon' => get_bloginfo('template_directory') . '/images/team.png',
		  'supports' => array('title','thumbnail','editor','custom-fields','page-attributes' ),
		  'query_var' => true,
		  'rewrite' => array( 'slug' => 'presentation' ),
		)
	  );
}
add_action( 'init', 'adapt_create_post_team' );
function adapt_create_post_team() {
	register_post_type( 'team',
		array(
		  'labels' => array(
			'name' => __( 'Team', '' ),
			'singular_name' => __( 'Team', '' ),		
			'add_new' => _x( 'Add New', 'Team', '' ),
			'add_new_item' => __( 'Add Team', '' ),
			'edit_item' => __( 'Edit Team', '' ),
			'new_item' => __( 'New Team', '' ),
			'view_item' => __( 'View Team', '' ),
			'search_items' => __( 'Search Team', '' ),
			'not_found' =>  __( 'No Team Found', '' ),
			'not_found_in_trash' => __( 'No Team found in Trash', '' ),
			'parent_item_colon' => ''		
		  ),
		  'public' => true,
		    'menu_icon' => get_bloginfo('template_directory') . '/images/team.png',
		  'supports' => array('title','thumbnail','editor','custom-fields','page-attributes' ),
		  'query_var' => true,
		  'rewrite' => array( 'slug' => 'doctors' ),
		)
	  );
}
add_action( 'init', 'adapt_create_post_testimonials' );
function adapt_create_post_testimonials() {
	register_post_type( 'testimonials',
		array(
		  'labels' => array(
			'name' => __( 'testimonials', '' ),
			'singular_name' => __( 'testimonials', '' ),		
			'add_new' => _x( 'Add New', 'testimonials', '' ),
			'add_new_item' => __( 'Add testimonials', '' ),
			'edit_item' => __( 'Edit testimonials', '' ),
			'new_item' => __( 'New testimonials', '' ),
			'view_item' => __( 'View testimonials', '' ),
			'search_items' => __( 'Search testimonials', '' ),
			'not_found' =>  __( 'No testimonials Found', '' ),
			'not_found_in_trash' => __( 'No testimonials found in Trash', '' ),
			'parent_item_colon' => ''		
		  ),
		  'public' => true,
		    'menu_icon' => get_bloginfo('template_directory') . '/images/team.png',
		  'supports' => array('title','editor','thumbnail','custom-fields'),
		  'query_var' => true,
		  'rewrite' => array( 'slug' => 'Testimonials' ),
		)
	  );
}
add_action( 'init', 'adapt_create_post_types' );
function adapt_create_post_types() {
	//portfolio post type
	register_post_type( 'portfolio',
		array(
		  'labels' => array(
			'name' => __( 'Portfolio', '' ),
			'singular_name' => __( 'Portfolio', '' ),		
			'add_new' => _x( 'Add New', 'Portfolio', '' ),
			'add_new_item' => __( 'Add New Portfolio', '' ),
			'edit_item' => __( 'Edit Portfolio', '' ),
			'new_item' => __( 'New Portfolio', '' ),
			'view_item' => __( 'View Portfolio', '' ),
			'search_items' => __( 'Search Portfolio', '' ),
			'not_found' =>  __( 'No Portfolio Found', '' ),
			'not_found_in_trash' => __( 'No Portfolio found in Trash', '' ),
			'parent_item_colon' => ''		
		  ),
		  'public' => true,
		    'menu_icon' => get_bloginfo('template_directory') . '/images/apartment.png',
		  'supports' => array('title','thumbnail'),
		  'query_var' => true,
		  'rewrite' => array( 'slug' => 'portfolio' ),
		)
	  );
}
add_action( 'init', 'adapt_create_post_news' );
function adapt_create_post_news() {
	//portfolio post type
	register_post_type( 'News',
		array(
		  'labels' => array(
			'name' => __( 'News', '' ),
			'singular_name' => __( 'News', '' ),		
			'add_new' => _x( 'Add News', 'Recruiter', '' ),
			'add_new_item' => __( 'Add News', '' ),
			'edit_item' => __( 'Edit News', '' ),
			'new_item' => __( 'New News', '' ),
			'view_item' => __( 'View News', '' ),
			'search_items' => __( 'Search News', '' ),
			'not_found' =>  __( 'No News Found', '' ),
			'not_found_in_trash' => __( 'No News found in Trash', '' ),
			'parent_item_colon' => ''		
		  ),
		  'public' => true,
		    'menu_icon' => get_bloginfo('template_directory') . '/images/apartment.png',
		  'supports' => array('title','editor','thumbnail'),
		  'query_var' => true,
		  'rewrite' => array( 'slug' => 'News' ),
		)
	  );
}
add_action( 'init', 'adapt_create_faq' );
function adapt_create_faq() {
	//portfolio post type
	register_post_type( 'faq',
		array(
		  'labels' => array(
			'name' => __( 'FAQ', '' ),
			'singular_name' => __( 'FAQ', '' ),		
			'add_new' => _x( 'Add New', 'FAQ', '' ),
			'add_new_item' => __( 'Add FAQ', '' ),
			'edit_item' => __( 'Edit FAQ', '' ),
			'new_item' => __( 'New FAQ', '' ),
			'view_item' => __( 'View FAQ', '' ),
			'search_items' => __( 'Search FAQ', '' ),
			'not_found' =>  __( 'No FAQ Found', '' ),
			'not_found_in_trash' => __( 'No FAQ found in Trash', '' ),
			'parent_item_colon' => ''		
		  ),
		  'public' => true,
		    'menu_icon' => get_bloginfo('template_directory') . '/images/apartment.png',
		  'supports' => array('title','editor','thumbnail'),
		  'query_var' => true,
		  'rewrite' => array( 'slug' => 'faqs' ),
		)
	  );
}
// Add taxonomies
add_action( 'init', 'adapt_create_taxonomies' );
function adapt_create_taxonomies()
{	
// portfolio taxonomies
	$cat_labels = array(
		'name' => __( 'Portfolio Categories', '' ),
		'singular_name' => __( 'Portfolio Category', '' ),
		'search_items' =>  __( 'Search Portfolio Categories', '' ),
		'all_items' => __( 'All Portfolio Categories', '' ),
		'parent_item' => __( 'Parent Portfolio Category', '' ),
		'parent_item_colon' => __( 'Parent Portfolio Category:', '' ),
		'edit_item' => __( 'Edit Portfolio Category', '' ),
		'update_item' => __( 'Update Portfolio Category', '' ),
		'add_new_item' => __( 'Add New Portfolio Category', '' ),
		'new_item_name' => __( 'New Portfolio Category Name', '' ),
		'choose_from_most_used'	=> __( 'Choose from the most used portfolio categories', '' )
	); 	

	register_taxonomy('portfolio_cats','portfolio',array(
		'hierarchical' => true,
		'labels' => $cat_labels,
		'query_var' => true,
		'rewrite' => array( 'slug' => 'portfolio-category' ),
	));
}
add_action( 'init', 'adapt_create_doctors_taxonomies' );
function adapt_create_doctors_taxonomies() {
	$doc_labels = array(
		'name' => __( 'Doctors Categories', '' ),
		'singular_name' => __( 'Doctors Category', '' ),
		'search_items' =>  __( 'Search Doctors Categories', '' ),
		'all_items' => __( 'All Doctors Categories', '' ),
		'parent_item' => __( 'Parent Doctors Category', '' ),
		'parent_item_colon' => __( 'Parent Doctors Category:', '' ),
		'edit_item' => __( 'Edit Doctors Category', '' ),
		'update_item' => __( 'Update Doctors Category', '' ),
		'add_new_item' => __( 'Add New Doctors Category', '' ),
		'new_item_name' => __( 'New Doctors Category Name', '' ),
		'choose_from_most_used'	=> __( 'Choose from the most used Doctors categories', '' )
	); 	
	register_taxonomy('doctor_cats','team',array(
		'hierarchical' => true,
		'labels' => $doc_labels,
		'query_var' => true,
		'rewrite' => array( 'slug' => 'Doctors' ),
	));
}
function dimox_breadcrumbs() {  
  
    /* === OPTIONS === */  
    $text['home']     = 'Home'; // text for the 'Home' link  
    $text['category'] = 'Archive by Category "%s"'; // text for a category page  
    $text['search']   = 'Search Results for "%s" Query'; // text for a search results page  
    $text['tag']      = 'Posts Tagged "%s"'; // text for a tag page  
    $text['author']   = 'Articles Posted by %s'; // text for an author page  
    $text['404']      = 'Error 404'; // text for the 404 page  
  
    $show_current   = 1; // 1 - show current post/page/category title in breadcrumbs, 0 - don't show  
    $show_on_home   = 0; // 1 - show breadcrumbs on the homepage, 0 - don't show  
    $show_home_link = 1; // 1 - show the 'Home' link, 0 - don't show  
    $show_title     = 1; // 1 - show the title for the links, 0 - don't show  
    $delimiter      = ' &raquo; '; // delimiter between crumbs  
    $before         = '<span class="current">'; // tag before the current crumb  
    $after          = '</span>'; // tag after the current crumb  
    /* === END OF OPTIONS === */  
  
    global $post;  
    $home_link    = home_url('/');  
    $link_before  = '<span typeof="v:Breadcrumb">';  
    $link_after   = '</span>';  
    $link_attr    = ' rel="v:url" property="v:title"';  
    $link         = $link_before . '<a' . $link_attr . ' href="%1$s">%2$s</a>' . $link_after;  
    $parent_id    = $parent_id_2 = $post->post_parent;  
    $frontpage_id = get_option('page_on_front');  
  
    if (is_home() || is_front_page()) {  
  
        if ($show_on_home == 1) echo '<div class="breadcrumbs"><a href="' . $home_link . '">' . $text['home'] . '</a></div>';  
  
    } else {  
  
        echo '<div class="breadcrumbs" xmlns:v="http://rdf.data-vocabulary.org/#">';  
        if ($show_home_link == 1) {  
           // echo sprintf($link, $home_link, $text['home']);  
            //if ($frontpage_id == 0 || $parent_id != $frontpage_id) echo $delimiter;  
        }  
  
        if ( is_category() ) {  
            $this_cat = get_category(get_query_var('cat'), false);  
            if ($this_cat->parent != 0) {  
                $cats = get_category_parents($this_cat->parent, TRUE, $delimiter);  
                if ($show_current == 0) $cats = preg_replace("#^(.+)$delimiter$#", "$1", $cats);  
                $cats = str_replace('<a', $link_before . '<a' . $link_attr, $cats);  
                $cats = str_replace('</a>', '</a>' . $link_after, $cats);  
                if ($show_title == 0) $cats = preg_replace('/ title="(.*?)"/', '', $cats);  
                echo $cats;  
            }  
            if ($show_current == 1) echo $before . sprintf($text['category'], single_cat_title('', false)) . $after;  
  
        } elseif ( is_search() ) {  
            echo $before . sprintf($text['search'], get_search_query()) . $after;  
  
        } elseif ( is_day() ) {  
            echo sprintf($link, get_year_link(get_the_time('Y')), get_the_time('Y')) . $delimiter;  
            echo sprintf($link, get_month_link(get_the_time('Y'),get_the_time('m')), get_the_time('F')) . $delimiter;  
            echo $before . get_the_time('d') . $after;  
  
        } elseif ( is_month() ) {  
            echo sprintf($link, get_year_link(get_the_time('Y')), get_the_time('Y')) . $delimiter;  
            echo $before . get_the_time('F') . $after;  
  
        } elseif ( is_year() ) {  
            echo $before . get_the_time('Y') . $after;  
  
        } elseif ( is_single() && !is_attachment() ) {  
            if ( get_post_type() != 'post' ) {  
                $post_type = get_post_type_object(get_post_type());  
                $slug = $post_type->rewrite;  
                printf($link, $home_link . '/' . $slug['slug'] . '/', $post_type->labels->singular_name);  
                if ($show_current == 1) echo $delimiter . $before . get_the_title() . $after;  
            } else {  
                $cat = get_the_category(); $cat = $cat[0];  
                $cats = get_category_parents($cat, TRUE, $delimiter);  
                if ($show_current == 0) $cats = preg_replace("#^(.+)$delimiter$#", "$1", $cats);  
                $cats = str_replace('<a', $link_before . '<a' . $link_attr, $cats);  
                $cats = str_replace('</a>', '</a>' . $link_after, $cats);  
                if ($show_title == 0) $cats = preg_replace('/ title="(.*?)"/', '', $cats);  
                echo $cats;  
                if ($show_current == 1) echo $before . get_the_title() . $after;  
            }  
  
        } elseif ( !is_single() && !is_page() && get_post_type() != 'post' && !is_404() ) {  
            $post_type = get_post_type_object(get_post_type());  
            echo $before . $post_type->labels->singular_name . $after;  
  
        } elseif ( is_attachment() ) {  
            $parent = get_post($parent_id);  
            $cat = get_the_category($parent->ID); $cat = $cat[0];  
            $cats = get_category_parents($cat, TRUE, $delimiter);  
            $cats = str_replace('<a', $link_before . '<a' . $link_attr, $cats);  
            $cats = str_replace('</a>', '</a>' . $link_after, $cats);  
            if ($show_title == 0) $cats = preg_replace('/ title="(.*?)"/', '', $cats);  
            echo $cats;  
            printf($link, get_permalink($parent), $parent->post_title);  
            if ($show_current == 1) echo $delimiter . $before . get_the_title() . $after;  
  
        } elseif ( is_page() && !$parent_id ) {  
            if ($show_current == 1) echo $before . get_the_title() . $after;  
  
        } elseif ( is_page() && $parent_id ) {  
            if ($parent_id != $frontpage_id) {  
                $breadcrumbs = array();  
                while ($parent_id) {  
                    $page = get_page($parent_id);  
                    if ($parent_id != $frontpage_id) {  
                        $breadcrumbs[] = sprintf($link, get_permalink($page->ID), get_the_title($page->ID));  
                    }  
                    $parent_id = $page->post_parent;  
                }  
                $breadcrumbs = array_reverse($breadcrumbs);  
                for ($i = 0; $i < count($breadcrumbs); $i++) {  
                    echo $breadcrumbs[$i];  
                    if ($i != count($breadcrumbs)-1) echo $delimiter;  
                }  
            }  
            if ($show_current == 1) {  
                if ($show_home_link == 1 || ($parent_id_2 != 0 && $parent_id_2 != $frontpage_id)) echo $delimiter;  
                echo $before . get_the_title() . $after;  
            }  
  
        } elseif ( is_tag() ) {  
            echo $before . sprintf($text['tag'], single_tag_title('', false)) . $after;  
  
        } elseif ( is_author() ) {  
            global $author;  
            $userdata = get_userdata($author);  
            echo $before . sprintf($text['author'], $userdata->display_name) . $after;  
  
        } elseif ( is_404() ) {  
            echo $before . $text['404'] . $after;  
        }  
  
        if ( get_query_var('paged') ) {  
            if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ' (';  
            echo __('Page') . ' ' . get_query_var('paged');  
            if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ')';  
        }  
  
        echo '</div><!-- .breadcrumbs -->';  
  
    }  
} // end dimox_breadcrumbs()  
add_action('woocommerce_before_main_content', 'wp176545_add_feature_image');
function wp176545_add_feature_image() {
echo "<div style='background:#CCC; overflow:hidden;position:relative;'>";
echo get_the_post_thumbnail( get_option( 'woocommerce_shop_page_id' ),'full' );
echo "</div>";
}
?>
