<?php 
/*
Template Name: FAQ Template
*/
?>
<?php get_header(); ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID),'full'); ?>
<?php if(isset($image[0])):?>
	<section class="module parallax_1 parallax_3" style="background:url(<?php echo $image[0]; ?>);background-size:cover;">
        <div class="container">
		<?php the_title("<h3 class='page-title'>","</h3>"); ?>
        </div>
    </section>
<?php else:?>
<div id="brief_intro">
		<div class="row">
			<div class="container">
				<div class="col-md-12 mobile_center">
					<h1 class="wow fadeInUp animated"><?php the_title();?></h1>
				</div>
			</div>
		</div>
</div>
<?php endif; endwhile;  endif; ?>
<!--/Ends brief intro -->
<div class="container">
		<div class="page_content">
		<div class="col-md-12">
		      <?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?>  
              <!--collapse-->
              <?php
                $k=0;
                global $post;
				$args = array( 'post_type' => 'faq', 'orderby'   => 'ID', 'posts_per_page' => -1,'order' => 'DESC','post_status' => 'publish',);
				$loop = new WP_Query( $args );
                while( $loop->have_posts() ) : $loop->the_post(); ?>
<a class="faq_title" role="button" data-toggle="collapse" href="#faq<?php the_ID();?>" aria-expanded="false" aria-controls="collapseExample">
                <i class="fa fa-caret-right"></i> <?php the_title();?>
                </a>
                <div class="collapse" id="faq<?php the_ID();?>">
                  <div class="well">
                    <?php the_excerpt();?>
                  </div>
                </div>
                     
					<?php 
					$k++;
					endwhile; ?>
               
             <!--ends /-->
		
		</div>
		</div>
</div>
<?php get_footer(); ?>