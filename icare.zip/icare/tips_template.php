<?php
/*
Template Name: Tips Template
*/
?>
<?php get_header(); ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div id="brief_intro">
		<div class="row">
			<div class="container">
				<div class="col-md-8 mobile_center">
					<h1 class="mobile_center"><?php the_title();?></h1>
				</div>
				<div class="col-md-4 hidden-xs">
					<a href="<?php echo get_permalink(18);?>" class="btn btn-default btn-lg">Learn More</a>
				</div>
			</div>
		</div>
</div>
<!--/Ends brief intro -->
<?php
endwhile; 
endif; ?>
<div class="container">
		<div class="page_content">
		<div class="col-md-9">
		<?php
				if ( get_query_var('paged') ) {
				   $paged = get_query_var('paged');
				} else if ( get_query_var('page') ) {
				   $paged = get_query_var('page');
				} else {
				   $paged = 1;
				}	
							$args = array( 'post_type' => 'tips', 'posts_per_page' => 6, 'paged' => $paged );
							$loop = new WP_Query( $args );
							while( $loop->have_posts() ) : $loop->the_post(); ?>
							<div class="col-md-12 newspost">

							
							<a href="<?php the_permalink();?>"><?php the_post_thumbnail('thumbnail',array("class"=>"img-responsive feature_image")); ?></a>
							<a href="<?php the_permalink();?>"> <?php the_title("<h3>","</h3>"); ?></a>
								<?php the_excerpt(); ?>
								<a href="<?php the_permalink(); ?>" >Read More</a>
							</div>
							<?php 
							$j=$j+1;
							endwhile; ?>
		</div>
		<div class="col-md-3">
			<?php get_sidebar(); ?>
		</div>
		</div>
</div>

<?php
if ( function_exists('vb_pagination') ) {
  vb_pagination($loop);
}
?>	




<?php 

get_footer();?>