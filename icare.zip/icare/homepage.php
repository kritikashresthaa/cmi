<?php 
/*
Template Name: Homepage Template
*/
?>
<?php get_header(); ?>
	<?php echo do_shortcode('[wonderplugin_slider id=1]'); ?>
<div class="clearfix"></div>
    <div class="container">
		<div class="row">
        <div class="col-md-12 text-center">
            <img src="https://www.aashas.com.np/wp-content/uploads/2019/05/aashas-physio-dental-team-1.jpg" class="img-responsive" alt="best-physiotherapist-dental-team-in-kathmandu" style="margin:50px auto 0px;" />
        </div>
    </div>
</div>
<div id="brief_intro">
		<div class="row1">
			<div class="container">
				<div class="col-md-7 mobile_center white">
					<h1 class="wow fadeInUp animated mobile_center">Fitness matters so does smile.</h1>
                    <p>We care for you just like your family member. we transform your smile, you transform your life.</p>
                    <a href="#physio" class="btn btn-default btn-lg">Learn More</a>
				</div>
				<div class="col-md-5 mobile_center white">
                    <?php dynamic_sidebar('workinghour');?>
				</div>
			</div>
		</div>
</div>
<!-- DEpartment -->
<!--facilities-->
<div class="box-section greybg">
	<div class="row1">
		<div class="container">
<a name="physio"></a>
            <div class="aashas_title title_pad" style="color:#FFF;">
                    <h6>AASHAS HEALTHCARE</h6>
                    <h1>OUR DEPARTMENTS</h1>
                </div>
<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingOne">
      <h4 class="panel-title">
        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          <img src="<?php echo get_template_directory_uri();?>/images/physio_icon.png" style="width:40px;"/>PHYSIOTHERAPY
        </a>
      </h4>
    </div>
    <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
      <div class="panel-body">
<?php
		  global $post;
$dental=get_post(64);
$args = array(
    'post_type'      => 'page',
    'posts_per_page' => -1,
    'post_parent'    => 64,
    'order'          => 'ASC',
    'orderby'        => 'menu_order'
 );
$parent = new WP_Query( $args ); ?>
        	<div class="col-md-6">
				<div class="experience">
                <p><?php echo substr($dental->post_content,0,200)."...";?></p></div>
					<ul>
                        <?php if($parent->have_posts()): ?>
                            <?php while ( $parent->have_posts() ) : $parent->the_post(); ?>
        <li><a href="<?php the_permalink();?>"><?php the_title();?></a></li>
                            <?php endwhile; ?>
                        <?php endif; 
                        wp_reset_postdata(); 
                        ?>
                        <ul>
				</div>
            <div class="col-md-6">
                        <div class="owl-carousel owl-theme" id="owl-physio" style="margin-top:50px;">
							 <?php 
							$c=0;
							while ( $parent->have_posts() ) : $parent->the_post(); ?>
                                <div class="item <?php echo ($c==0)?'active':'';?>">
                              <img src="<?php echo get_post_meta($post->ID,'page_quick_image',true);?>" class="img-responsive" />
                                </div>
							 <?php endwhile; ?>
                               
                  </div>
            </div>
      </div>
    </div>
  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingTwo">
      <h4 class="panel-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
         <img src="<?php echo get_template_directory_uri();?>/images/dental_icon.png" style="width:40px;"/> &nbsp; DENTAL SERVICE
        </a>
      </h4>
    </div>
    <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
      <div class="panel-body">
         <?php
$dental=get_post(66);
$args = array(
    'post_type'      => 'page',
    'posts_per_page' => -1,
    'post_parent'    => 66,
    'order'          => 'ASC',
    'orderby'        => 'menu_order'
 );
$parent = new WP_Query( $args ); ?>
        	<div class="col-md-6">
				<div class="experience">
                <p><?php echo substr($dental->post_content,0,200);?></p></div>
					<ul>
                        <?php if($parent->have_posts()): ?>
                            <?php while ( $parent->have_posts() ) : $parent->the_post(); ?>
                            <li><a href="<?php the_permalink();?>"><?php the_title();?></a></li>
                            <?php endwhile; ?>
                        <?php endif; 
                        wp_reset_postdata(); 
                        ?>
                        <ul>
				</div>
            <div class="col-md-6">
                        <div class="owl-carousel owl-theme" id="owl-dental" style="margin-top:50px;">
                                <div class="item">
                                    <img src="https://www.aashas.com.np/wp-content/uploads/2019/03/dental.png" class="img-responsive"/>
                                </div>
                                <div class="item">
                                    <img src="https://www.aashas.com.np/wp-content/uploads/2019/03/root-canal.png" class="img-responsive" />
                                </div>
                                <div class="item">
                                    <img src="https://www.aashas.com.np/wp-content/uploads/2019/03/scaling.jpg" class="img-responsive" />
                                </div>
                                
                  </div>
            </div>
      </div>
    </div>
                
          </div> 
         
      </div>
    </div>
  </div>
</div>   
</div>
        </div></div>
<!--/Ends brief intro -->
<!-- testimonials -->
<section class="box-section module parallax-1 parallax_3-1" style="background:#FFF;"> 				
	<div class="container">
		<div class="row1">
			<div class="col-md-12">
                <div class="aashas_title padbottom">
                    <h6>AASHAS HEALTHCARE</h6>
                    <h1>PATIENT'S SPEAK</h1>
                </div>
				<div class="col-md-4">
					<div class="owl-carousel owl-theme" id="owl-clients">
				  <?php
				  $k=0;
					$args = array( 'post_type' => 'testimonials', 'orderby'   => 'ID', 'posts_per_page' => 7,'order' => 'DESC','post_status' => 'publish',);
									$loop = new WP_Query( $args );
									while( $loop->have_posts() ) : $loop->the_post(); ?>
									<div class="item-test">
                                             <a href="<?php echo get_post_meta( $post->ID, 'youtube_video_id', true );?>" target="_blank"><?php the_post_thumbnail('gal_vthumb',array('class'=>'img-responsive'));?></a>
										<h4><i  class="fa fa-play-circle"></i> <?php the_title();?>
										</h4>
                                    </div><!--/item-->
                     
					<?php 
					$k++;
					endwhile; ?>
				  </div>
				</div>
				<div class="col-md-3">
					<p>
						Feedback and suggestions are always appreciated. Good comments drive us to do much better in this field and those suggestive comments help us rectify our weakness and walk ahead with strengthened motives.
					</p>
				</div>
				<div class="col-md-5">
					<?php dynamic_sidebar('fb_review'); ?>
				</div>
				
				</div>
			</div>
	</div>
</section>
<!-- Request Call -->
    <div id="brief_intro">
		<div class="row1">
			<div class="container">
				<div class="col-md-7 mobile_center">
					<h1 class="wow fadeInUp animated mobile_center">Special Group Discussion</h1>
                    <p class="white">We organise special group discussion in specific topic for patient. (Sharing Knowledge is creating awareness)</p>
				</div>
				<div class="col-md-5 mobile_center">
					<?php dynamic_sidebar('specialform');?>

				</div>
			</div>
		</div>
</div>
<!-- blog -->
<div class="row" style = "display:inline">
 <div class="container">
                <div class="aashas_title title_pad" >
                    <h6>AASHAS HEALTHCARE</h6>
                    <h1>OUR BLOG POSTS</h1>
					<span style="float:right;margin-top:-20px;"><a href="https://www.aashas.com.np/blog/">View All</a></span>
                </div>
            <?php
			$args = array( 'post_type' => 'post', 'posts_per_page' => 3, 'paged' => $paged );
			$loop = new WP_Query( $args );
			while( $loop->have_posts() ) : $loop->the_post(); ?>
			  <div class="col-sm-6 col-md-4">
                <div class="thumbnail">
                  <?php the_post_thumbnail('gal-vthumb');?>
                  <div class="caption">
                    <?php the_title("<h3>","</h3>");?>
                    <?php the_excerpt();?>
                   
                  </div>
                </div>
              </div>
                 <!--  -->
			<?php endwhile;?>
    </div>
</div>
<?php get_footer(); ?>
