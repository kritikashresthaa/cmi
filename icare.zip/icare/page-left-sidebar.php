<?php
/*
Template Name: Left Sidebar Page
*/
?>
<?php get_header(); ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID),'full'); ?>

	<section class="module parallax_1 parallax_3" style="background:url(<?php echo $image[0]; ?>);">
        <div class="container">
		<?php the_title("<h3 class='page-title'>","</h3>"); ?>
        </div>
    </section>
<div class="container">

		<div class="page_content">
		
		<div class="col-md-9">
		<?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?>  
		<?php the_content(); ?>
		</div>
		<?php get_sidebar();?>
		</div>
</div>
<?php endwhile; ?>		
					<?php else : ?>
					<div class="container">
					<div class="page_content">
					<div class="col-md-12">
					    <header>
					    	<h1><?php _e("Not Found", "wpbootstrap"); ?></h1>
					    </header>
					    <section class="post_content">
					    	<p><?php _e("Sorry, but the requested resource was not found on this site.", "wpbootstrap"); ?></p>
					    </section>
					</div>
					</div>
					</div>
					<?php endif; ?>
<?php get_footer(); ?>