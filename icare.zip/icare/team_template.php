<?php
/*
Template Name: Team Page
*/
?>
<?php get_header(); ?>
<?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID),'full'); ?>
<?php if(isset($image[0])):?>
	<section class="module parallax_1 parallax_3" style="background:url(<?php echo $image[0]; ?>);">
        <div class="container">
		<?php the_title("<h3 class='page-title'>","</h3>"); ?>
        </div>
    </section>
<?php else:?>
<div id="brief_intro">
		<div class="row">
			<div class="container">
				<div class="col-md-8 mobile_center">
					<h1 class="wow fadeInUp animated"><?php the_title();?></h1>
				</div>
				
				</div>
			</div>
		</div>
</div>
<!--/Ends brief intro -->
<?php endif; ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="container">
		<div class="page_content myarticle">
			<div class="col-md-12">
			<?php the_content(); ?>
			<br/>
			<?php
                $fabricTerms = get_terms( 'doctor_cats',array('orderby'=>'term_id','order'=>'ASC')); 
                foreach($fabricTerms as $fabricTerm){
                ?>
                        <?php
                        global $wpdb;
                        // create blank array..
                        $fabricPosts = array();
                        // find term_id for sub-category..
                        $fabric_category_term_id = $wpdb->get_results( "SELECT term_id FROM {$wpdb->terms} WHERE name = '".$fabricTerm->name."'  " );
                        foreach($fabric_category_term_id as $fc_id){
                            // find taxonomy_ids from term_id..
                            $fabric_taxonomy_id = $wpdb->get_results( "SELECT term_taxonomy_id FROM {$wpdb->term_taxonomy} WHERE term_id = ".$fc_id->term_id." order by term_id DESC" );
                            foreach($fabric_taxonomy_id as $ft_id){
                                // find object_id from taxonomy_id..
                                $fabric_object_id = $wpdb->get_results( "SELECT object_id FROM {$wpdb->term_relationships} WHERE term_taxonomy_id = ".$ft_id->term_taxonomy_id." " );
                                foreach($fabric_object_id as $fo_id){
                                    // add object_id to array..
                                    array_push($fabricPosts, $fo_id->object_id);
                                }
                            }
                        }
                        // if less than 5 posts, get number of posts to detirmine number of loops..
                        if( count($fabricPosts) < 1 ){
                            $loops = count($fabricPosts);
                        }
                        else {
                            $loops = 1;
                        }
                        // loop through posts..
                        for($v=0; $v<$loops; $v++){
                            // get the 1st element from the array..
                            $fabricPost = array_shift($fabricPosts);
                            // get post data..
                            $post = get_post($fabricPost);	
                            ?>
							<div class="col-md-12 col-xs-12 nopadding">
							<a name="<?php echo $fabricTerm->name;?>"></a>
							<div class="panel panel-default doc-panel">
								<div class="panel-heading" style="padding:15px;">:: <?php echo $fabricTerm->name;?></div>
								<div class="panel-body">
								   <?php
								query_posts(array(
										'term' => $fabricTerm->name,
										'post_type'=>'team',
										'posts_per_page' => -1,
										'taxonomy'=>'doctor_cats',
                                        'orderby'=> 'menu_order',
                                        'order'=>'ASC',
									));
									?>       
											<?php
											$count=0;
											while (have_posts()) : the_post(); ?>
															 <div class="col-md-3 wow animated bounceInUp" data-wow-delay="<?php echo $k+0.1;?>s">
																<div class="doctors_pack">
																	<div class="nopadding packs text-center">
																			<?php the_post_thumbnail('gal-thumb',array('class'=>'img-responsive'));?>
																	           <div class="doctors_short">
																				<a href="<?php the_permalink();?>"><?php the_title("<h4 class='doc_title'>","</h4>");?></a>
																			
                                                                        </div>
																				
																	
																	<div class="clearfix"></div>
																	</div>
																</div>
																</div>
																
												<?php 
												$k+=0.1;
												$j++;
												?>
											  <?php
											 endwhile; 
											 wp_reset_query(); 
											 ?>
								</div>
								</div>  
</div>								
<?php  
 }   
}						
?>             
			</div>
		</div>
	</div>
<?php endwhile; ?>		
					<?php else : ?>
					<div class="container" style="padding-bottom:40px;">
					<div class="page_content">
					<div class="col-md-12">
					    <header>
					    	<h1><?php _e("Not Found", "wpbootstrap"); ?></h1>
					    </header>
					    <section class="post_content">
					    	<p><?php _e("Sorry, but the requested resource was not found on this site.", "wpbootstrap"); ?></p>
					    </section>
					</div>
					</div>
					</div>
					<?php endif; ?>
<?php get_footer(); ?>